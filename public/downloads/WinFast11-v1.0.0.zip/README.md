# 🚀 WinFast 11 — Ultimate Windows 11 Speedup & Debloat Suite

[![Windows 11](https://img.shields.io/badge/Platform-Windows%2011-0078D4?logo=windows11&logoColor=white)](#)
[![PowerShell](https://img.shields.io/badge/Language-PowerShell-5391FE?logo=powershell&logoColor=white)](#)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Open Source Love](https://badges.frapsoft.com/os/v1/open-source.svg?v=103)](#)
[![Safe & Verified](https://img.shields.io/badge/Status-100%25%20Safe%20%26%20Audited-success)](#)

> **Make your Windows 11 lightning fast with zero risk.**  
> A lightweight, open-source optimizer that clears system junk, disables telemetry/tracking, activates hidden performance power plans, and restores peak gaming & multitasking speed.

---

## ✨ Key Features

* 🛡️ **Zero-Risk Safety**: Automatically creates a **System Restore Point** before making any changes.
* 🧹 **Deep Junk & Cache Purge**: Safely wipes `%temp%`, Windows Prefetch, and temporary update download caches.
* 🔕 **Disable Telemetry & Ad Tracking**: Halts background diagnostic reporting (`DiagTrack`) and Windows targeted ad services to reclaim CPU cycles.
* ⚡ **Ultimate Performance Power Plan**: Activates Windows' hidden ultra-responsive power profile (eliminates micro-stutters in games and heavy software).
* 🏎️ **Instant UI Responsiveness**: Cuts explorer menu delay down to 50ms and removes Windows startup delay.
* 🎮 **Gaming & GPU Scheduling**: Ensures Windows Game Mode and Hardware-Accelerated GPU Scheduling (HAGS) are enabled.
* 📦 **100% Transparent & Open Source**: No shady background installers or binaries. Inspect the pure PowerShell source code before running!

---

## ⚡ Quick Start (3 Easy Ways)

### Method 1: Standalone Executable (`WinFast11.exe`) — Easiest!
1. Go to [Releases](https://github.com/nextsemacademy-max/winfast11/releases) and download **`WinFast11.exe`**.
2. Double-click **`WinFast11.exe`** (Windows will automatically request Administrator elevation).
3. The interactive menu will open — press `[1]` for Full Turbo Optimization!

---

### Method 2: Instant One-Liner (Fastest — No Download Required)
Open **PowerShell as Administrator** (Win + X -> Terminal/PowerShell as Admin) and paste:

```powershell
irm https://raw.githubusercontent.com/nextsemacademy-max/winfast11/main/WinFast.ps1 | iex
```

---

### Method 3: Download Zip & Batch Launcher
1. Download `WinFast11-v1.0.0.zip` from [Releases](https://github.com/nextsemacademy-max/winfast11/releases).
2. Extract and double-click **`Run-WinFast.bat`**.

---

## 🖥️ Interactive Menu Preview

```text
=================================================================
   __      ___       ______        _     __ __                   
   \ \    / (_)     |  ____|      | |   /_ /_ |                  
    \ \  / / _ _ __ | |__ __ _ ___| |_   | || |                  
     \ \/ / | | '_ \|  __/ _` / __| __|  | || |                  
      \  /  | | | | | | | (_| \__ \ |_   | || |                  
       \/   |_|_| |_|_|  \__,_|___/\__|  |_||_|                  
                                                                 
      Windows 11 Speedup, Debloat & Performance Suite           
           Developed by Manoj • Copyright (c) NextSem           
=================================================================

 Select an action:
  [1] 🚀 Full Turbo Optimization (Recommended - All in One)
  [2] 🧹 Deep Junk & Cache Purge (Frees Disk Space)
  [3] 🔕 Disable Telemetry & Background Tracking (Saves RAM/CPU)
  [4] ⚡ Enable Ultimate Performance Power Plan
  [5] 🏎️ Optimize UI & Remove Startup Delays
  [6] 🎮 Enable Game Mode & GPU Scheduling
  [7] 🛡️ Create System Restore Point Now
  [Q] ❌ Exit
```

---

## 🛡️ Safety & Disclaimer

* **Safe Tweaks Only**: This utility only removes safe temporary files and turns off diagnostic background threads. It **NEVER** deletes Microsoft Store, critical drivers, or core Windows components.
* **Undo / Revert**: If you ever want to revert, simply open Windows System Restore and restore the auto-created checkpoint: `WinFast11_BeforeOptimization`.

---

## 👨‍💻 Author & Credits

* **Developer**: Developed by Manoj
* **Copyright**: Copyright © NextSem ([Nextsem](https://nextsem.online))
* **Contributions**: Pull requests, bug reports, and suggestions are welcome! Feel free to star ⭐ this repository if it helped your PC speed up.

---

## 📜 License

Distributed under the **MIT License**. See `LICENSE` for details.
