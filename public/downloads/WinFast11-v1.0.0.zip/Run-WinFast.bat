@echo off
:: =========================================================================
::  WinFast 11 - Launcher (Auto Admin Elevation)
::  Developed by Manoj | Copyright (c) NextSem
:: =========================================================================
title WinFast 11 - Ultimate Windows Optimizer

:: Check for Administrative Rights
net session >nul 2>&1
if %errorlevel% == 0 (
    goto :run_powershell
) else (
    goto :elevate_admin
)

:elevate_admin
echo.
echo =========================================================
echo  Requesting Administrator Privileges...
echo =========================================================
echo Set UAC = CreateObject^("Shell.Application"^) > "%temp%\winfast_admin.vbs"
echo UAC.ShellExecute "cmd.exe", "/c cd /d """%~dp0""" && call """%~f0"""", "", "runas", 1 >> "%temp%\winfast_admin.vbs"
"%temp%\winfast_admin.vbs"
del "%temp%\winfast_admin.vbs"
exit /b

:run_powershell
cls
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0WinFast.ps1"
if %errorlevel% neq 0 (
    echo.
    echo Script ended or interrupted.
    pause
)
exit /b
